from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"


# --- Models ---

class Role:
    ADMIN = "admin"
    USER = "user"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default=Role.USER)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    rentals = db.relationship("Rental", backref="user", lazy="dynamic")
    notifications = db.relationship("Notification", backref="user", lazy="dynamic")

    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)
    def is_admin(self): return self.role == Role.ADMIN


class BookStatus:
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    ARCHIVED = "archived"


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(120), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, default="")
    status = db.Column(db.String(20), default=BookStatus.AVAILABLE)
    price_purchase = db.Column(db.Float, default=0.0)
    price_rent_2w = db.Column(db.Float, default=0.0)
    price_rent_1m = db.Column(db.Float, default=0.0)
    price_rent_3m = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class RentalType:
    PURCHASE = "purchase"
    RENT = "rent"


class Rental(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey("book.id"), nullable=False)
    book = db.relationship("Book")
    type = db.Column(db.String(20), default=RentalType.RENT)
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)  # None for purchases
    price = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(20), default="active")  # active/returned/completed/overdue
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    rental_id = db.Column(db.Integer, db.ForeignKey("rental.id"), nullable=True)
    message = db.Column(db.String(400), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    seen = db.Column(db.Boolean, default=False)


@login_manager.user_loader
def load_user(user_id): return User.query.get(int(user_id))


# --- Helpers ---

def admin_required():
    if not current_user.is_authenticated or not current_user.is_admin():
        abort(403)


def apply_sorting(query):
    category = request.args.get("category")
    author = request.args.get("author")
    year = request.args.get("year")
    if category:
        query = query.filter(Book.category.ilike(f"%{category.strip()}%"))
    if author:
        query = query.filter(Book.author.ilike(f"%{author.strip()}%"))
    if year:
        try:
            y = int(year)
            query = query.filter(Book.year == y)
        except:
            pass
    sort = request.args.get("sort", "title")
    if sort == "author":
        query = query.order_by(Book.author.asc(), Book.title.asc())
    elif sort == "year":
        query = query.order_by(Book.year.desc(), Book.title.asc())
    else:
        query = query.order_by(Book.title.asc())
    return query


def rental_price(book: Book, period: str):
    if period == "2w": return book.price_rent_2w
    if period == "1m": return book.price_rent_1m
    if period == "3m": return book.price_rent_3m
    return 0.0


def rental_end_date(period: str):
    if period == "2w": return datetime.utcnow() + timedelta(days=14)
    if period == "1m": return datetime.utcnow() + timedelta(days=30)
    if period == "3m": return datetime.utcnow() + timedelta(days=90)
    return None


# --- Routes: public & user ---

@app.route("/")
def index():
    q = Book.query.filter(Book.status == BookStatus.AVAILABLE)
    books = apply_sorting(q).limit(50).all()
    return render_template("index.html", books=books)


@app.route("/book/<int:book_id>")
def book_detail(book_id):
    book = Book.query.get_or_404(book_id)
    return render_template("book_detail.html", book=book)


@app.route("/rent/<int:book_id>", methods=["POST"])
@login_required
def rent_book(book_id):
    book = Book.query.get_or_404(book_id)
    if book.status != BookStatus.AVAILABLE:
        flash("Книга недоступна для аренды.", "warning")
        return redirect(url_for("book_detail", book_id=book.id))
    period = request.form.get("period", "2w")
    price = rental_price(book, period)
    end_date = rental_end_date(period)
    r = Rental(user=current_user, book=book, type=RentalType.RENT, price=price, end_date=end_date, status="active")
    db.session.add(r)
    db.session.commit()
    flash("Аренда оформлена.", "success")
    return redirect(url_for("my_rentals"))


@app.route("/purchase/<int:book_id>", methods=["POST"])
@login_required
def purchase_book(book_id):
    book = Book.query.get_or_404(book_id)
    if book.status == BookStatus.ARCHIVED:
        flash("Книга недоступна для покупки.", "warning")
        return redirect(url_for("book_detail", book_id=book.id))
    r = Rental(user=current_user, book=book, type=RentalType.PURCHASE, price=book.price_purchase, end_date=None, status="completed")
    db.session.add(r)
    db.session.commit()
    flash("Покупка оформлена.", "success")
    return redirect(url_for("my_rentals"))


@app.route("/my/rentals")
@login_required
def my_rentals():
    rentals = current_user.rentals.order_by(Rental.created_at.desc()).all()
    return render_template("my_rentals.html", rentals=rentals)


# --- Auth ---

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not username or not email or not password:
            flash("Заполните все поля.", "danger")
            return redirect(url_for("register"))
        if User.query.filter((User.username==username)|(User.email==email)).first():
            flash("Пользователь с таким именем или email уже существует.", "danger")
            return redirect(url_for("register"))
        u = User(username=username, email=email)
        u.set_password(password)
        db.session.add(u); db.session.commit()
        flash("Регистрация успешна. Войдите.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash("Добро пожаловать!", "success")
            return redirect(url_for("index"))
        flash("Неверные логин/пароль.", "danger")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли.", "info")
    return redirect(url_for("index"))


# --- Admin ---

@app.route("/admin")
@login_required
def admin_index():
    admin_required()
    total = Book.query.count()
    active = Book.query.filter(Book.status == BookStatus.AVAILABLE).count()
    rentals_active = Rental.query.filter(Rental.status=="active").count()
    return render_template("admin/index.html", total=total, active=active, rentals_active=rentals_active)


@app.route("/admin/books")
@login_required
def admin_books():
    admin_required()
    books = Book.query.order_by(Book.created_at.desc()).all()
    return render_template("admin/books.html", books=books)


@app.route("/admin/books/new", methods=["GET","POST"])
@login_required
def admin_books_new():
    admin_required()
    if request.method == "POST":
        b = Book(
            title=request.form.get("title","").strip(),
            author=request.form.get("author","").strip(),
            category=request.form.get("category","").strip(),
            year=int(request.form.get("year","0") or 0),
            description=request.form.get("description","").strip(),
            status=request.form.get("status","available"),
            price_purchase=float(request.form.get("price_purchase","0") or 0),
            price_rent_2w=float(request.form.get("price_rent_2w","0") or 0),
            price_rent_1m=float(request.form.get("price_rent_1m","0") or 0),
            price_rent_3m=float(request.form.get("price_rent_3m","0") or 0),
        )
        db.session.add(b); db.session.commit()
        flash("Книга добавлена.", "success")
        return redirect(url_for("admin_books"))
    return render_template("admin/book_form.html", book=None)


@app.route("/admin/books/<int:book_id>/edit", methods=["GET","POST"])
@login_required
def admin_books_edit(book_id):
    admin_required()
    b = Book.query.get_or_404(book_id)
    if request.method == "POST":
        b.title = request.form.get("title","").strip()
        b.author = request.form.get("author","").strip()
        b.category = request.form.get("category","").strip()
        b.year = int(request.form.get("year","0") or 0)
        b.description = request.form.get("description","").strip()
        b.status = request.form.get("status","available")
        b.price_purchase = float(request.form.get("price_purchase","0") or 0)
        b.price_rent_2w = float(request.form.get("price_rent_2w","0") or 0)
        b.price_rent_1m = float(request.form.get("price_rent_1m","0") or 0)
        b.price_rent_3m = float(request.form.get("price_rent_3m","0") or 0)
        db.session.commit()
        flash("Книга обновлена.", "success")
        return redirect(url_for("admin_books"))
    return render_template("admin/book_form.html", book=b)


@app.route("/admin/books/<int:book_id>/delete", methods=["POST"])
@login_required
def admin_books_delete(book_id):
    admin_required()
    b = Book.query.get_or_404(book_id)
    db.session.delete(b); db.session.commit()
    flash("Книга удалена.", "info")
    return redirect(url_for("admin_books"))


@app.route("/admin/rentals")
@login_required
def admin_rentals():
    admin_required()
    rentals = Rental.query.order_by(Rental.created_at.desc()).all()
    return render_template("admin/rentals.html", rentals=rentals)


@app.route("/admin/send-reminders", methods=["POST"])
@login_required
def admin_send_reminders():
    admin_required()
    sent = send_due_reminders()
    flash(f"Отправлено напоминаний: {sent}", "success")
    return redirect(url_for("admin_rentals"))


# --- Reminders job ---

def send_due_reminders():
    now = datetime.utcnow()
    count = 0
    # напоминания за 1 день до окончания и в день просрочки
    rentals = Rental.query.filter(Rental.type==RentalType.RENT, Rental.status=="active").all()
    for r in rentals:
        if not r.end_date:
            continue
        days_left = (r.end_date.date() - now.date()).days
        msg = None
        if days_left == 1:
            msg = f"Срок аренды книги «{r.book.title}» заканчивается завтра ({r.end_date.date()})."
        elif days_left == 0:
            msg = f"Сегодня заканчивается срок аренды книги «{r.book.title}»."
        elif days_left < 0:
            r.status = "overdue"
            msg = f"Просрочен срок аренды книги «{r.book.title}» (закончился {r.end_date.date()})."
        if msg:
            n = Notification(user_id=r.user_id, rental_id=r.id, message=msg)
            db.session.add(n); count += 1
    db.session.commit()
    return count


# CLI
@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("База данных инициализирована.")


@app.cli.command("create-admin")
def create_admin():
    if User.query.filter_by(username="admin").first():
        print("Админ уже существует.")
        return
    u = User(username="admin", email="admin@example.com", role=Role.ADMIN)
    u.set_password("admin123")
    db.session.add(u); db.session.commit()
    print("Создан администратор: admin / admin123")


@app.cli.command("seed-db")
def seed_db():
    import random
    if Book.query.count() > 0:
        print("Книги уже есть.")
        return
    samples = [
        dict(title="Мастер и Маргарита", author="Михаил Булгаков", category="Классика", year=1967),
        dict(title="Преступление и наказание", author="Фёдор Достоевский", category="Классика", year=1866),
        dict(title="Над пропастью во ржи", author="Дж. Д. Сэлинджер", category="Роман", year=1951),
        dict(title="Три товарища", author="Эрих Мария Ремарк", category="Роман", year=1936),
        dict(title="Чистый код", author="Роберт Мартин", category="IT", year=2008),
        dict(title="Война и мир", author="Лев Толстой", category="Классика", year=1869),
        dict(title="Пикник на обочине", author="Стругацкие", category="Фантастика", year=1972),
        dict(title="451° по Фаренгейту", author="Рэй Брэдбери", category="Фантастика", year=1953),
    ]
    for s in samples:
        b = Book(
            **s,
            description="Описание книги.",
            status=BookStatus.AVAILABLE,
            price_purchase=round(random.uniform(9, 25), 2),
            price_rent_2w=round(random.uniform(2, 5), 2),
            price_rent_1m=round(random.uniform(3, 7), 2),
            price_rent_3m=round(random.uniform(5, 10), 2),
        )
        db.session.add(b)
    db.session.commit()
    print("Добавлены книги (seed).")


@app.cli.command("send-reminders")
def cli_send_reminders():
    sent = send_due_reminders()
    print(f"Отправлено напоминаний: {sent}")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
