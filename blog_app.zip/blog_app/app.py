from datetime import datetime
from enum import Enum
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

from config import Config

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"


# --- Models ---

class Visibility(str, Enum):
    PUBLIC = "public"
    FOLLOWERS = "followers"
    REQUEST = "request"  # только по запросу


followers = db.Table(
    "followers",
    db.Column("follower_id", db.Integer, db.ForeignKey("user.id")),
    db.Column("followed_id", db.Integer, db.ForeignKey("user.id"))
)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    posts = db.relationship("Post", backref="author", lazy="dynamic")
    comments = db.relationship("Comment", backref="author", lazy="dynamic")

    followed = db.relationship(
        "User",
        secondary=followers,
        primaryjoin=(followers.c.follower_id == id),
        secondaryjoin=(followers.c.followed_id == id),
        backref=db.backref("followers", lazy="dynamic"),
        lazy="dynamic"
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_following(self, user):
        return self.followed.filter(followers.c.followed_id == user.id).count() > 0

    def follow(self, user):
        if not self.is_following(user):
            self.followed.append(user)

    def unfollow(self, user):
        if self.is_following(user):
            self.followed.remove(user)


post_tags = db.Table(
    "post_tags",
    db.Column("post_id", db.Integer, db.ForeignKey("post.id")),
    db.Column("tag_id", db.Integer, db.ForeignKey("tag.id"))
)


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    visibility = db.Column(db.Enum(Visibility), default=Visibility.PUBLIC, nullable=False)

    tags = db.relationship("Tag", secondary=post_tags, backref=db.backref("posts", lazy="dynamic"))
    comments = db.relationship("Comment", backref="post", cascade="all, delete-orphan", lazy="dynamic")
    access_requests = db.relationship("AccessRequest", backref="post", cascade="all, delete-orphan", lazy="dynamic")


class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AccessRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"), nullable=False)
    requester_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    requester = db.relationship("User", foreign_keys=[requester_id])
    status = db.Column(db.String(20), default="pending")  # pending/approved/denied
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint("post_id", "requester_id", name="uix_post_requester"),)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# --- Utilities ---

def parse_tags(tags_raw):
    names = [t.strip().lower() for t in (tags_raw or "").split(",") if t.strip()]
    tags = []
    for name in dict.fromkeys(names):  # remove duplicates, keep order
        tag = Tag.query.filter_by(name=name).first()
        if not tag:
            tag = Tag(name=name)
            db.session.add(tag)
        tags.append(tag)
    return tags


def can_view_post(user, post: Post):
    if post.visibility == Visibility.PUBLIC:
        return True
    if not user:
        return False
    if post.author.id == user.id:
        return True
    if post.visibility == Visibility.FOLLOWERS and post.author.is_following(user) or user.is_following(post.author):
        # followers visibility: allow if viewer follows author (mutual not required)
        return user.is_following(post.author)
    if post.visibility == Visibility.REQUEST:
        # allowed if approved
        approved = AccessRequest.query.filter_by(post_id=post.id, requester_id=user.id, status="approved").first()
        return approved is not None
    return False


# --- Routes ---

@app.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("feed"))
    posts = Post.query.filter(Post.visibility == Visibility.PUBLIC).order_by(Post.created_at.desc()).limit(20).all()
    return render_template("index.html", posts=posts)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not username or not email or not password:
            flash("Заполните все поля.", "danger")
            return redirect(url_for("register"))
        if User.query.filter((User.username == username)|(User.email == email)).first():
            flash("Пользователь с таким именем или email уже существует.", "danger")
            return redirect(url_for("register"))
        u = User(username=username, email=email)
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        flash("Регистрация успешна. Войдите в систему.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash("Добро пожаловать!", "success")
            return redirect(url_for("feed"))
        flash("Неверные имя пользователя или пароль.", "danger")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("index"))


@app.route("/profile/<username>")
def profile(username):
    user = User.query.filter_by(username=username.lower()).first_or_404()
    posts = user.posts.order_by(Post.created_at.desc()).all()
    is_following = current_user.is_authenticated and current_user.is_following(user)
    return render_template("profile.html", user=user, posts=posts, is_following=is_following)


@app.route("/follow/<username>", methods=["POST"])
@login_required
def follow(username):
    user = User.query.filter_by(username=username.lower()).first_or_404()
    if user.id == current_user.id:
        flash("Нельзя подписаться на самого себя.", "warning")
    else:
        current_user.follow(user)
        db.session.commit()
        flash(f"Вы подписались на @{user.username}.", "success")
    return redirect(url_for("profile", username=user.username))


@app.route("/unfollow/<username>", methods=["POST"])
@login_required
def unfollow(username):
    user = User.query.filter_by(username=username.lower()).first_or_404()
    current_user.unfollow(user)
    db.session.commit()
    flash(f"Вы отписались от @{user.username}.", "info")
    return redirect(url_for("profile", username=user.username))


@app.route("/feed")
@login_required
def feed():
    # Посты авторов, на которых текущий пользователь подписан
    followed_ids = [u.id for u in current_user.followed.all()]
    q = Post.query.filter(Post.user_id.in_(followed_ids))
    # при этом показываем только разрешённые по видимости (followers/request logic внутри списка)
    posts = [p for p in q.order_by(Post.created_at.desc()).limit(100).all() if can_view_post(current_user, p)]
    # сортировка по параметру
    sort = request.args.get("sort","recent")
    if sort == "comments":
        posts.sort(key=lambda p: p.comments.count(), reverse=True)
    return render_template("feed.html", posts=posts, sort=sort)


@app.route("/explore")
def explore():
    tag = request.args.get("tag")
    sort = request.args.get("sort","recent")
    q = Post.query
    if tag:
        t = Tag.query.filter_by(name=tag.lower()).first()
        if t:
            q = t.posts
        else:
            q = Post.query.filter(db.text("0"))  # пустой
    q = q.filter(Post.visibility == Visibility.PUBLIC)
    posts = q.order_by(Post.created_at.desc()).all()
    if sort == "comments":
        posts.sort(key=lambda p: p.comments.count(), reverse=True)
    return render_template("explore.html", posts=posts, selected_tag=tag, sort=sort)


@app.route("/post/new", methods=["GET", "POST"])
@login_required
def new_post():
    if request.method == "POST":
        title = request.form.get("title","").strip()
        body = request.form.get("body","").strip()
        tags_raw = request.form.get("tags","")
        visibility = request.form.get("visibility","public")
        if not title or not body:
            flash("Заголовок и текст обязательны.", "danger")
            return redirect(url_for("new_post"))
        post = Post(
            author=current_user,
            title=title,
            body=body,
            visibility=Visibility(visibility)
        )
        post.tags = parse_tags(tags_raw)
        db.session.add(post)
        db.session.commit()
        flash("Пост опубликован.", "success")
        return redirect(url_for("post_detail", post_id=post.id))
    return render_template("new_post.html")


@app.route("/post/<int:post_id>")
def post_detail(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user if current_user.is_authenticated else None, post):
        if post.visibility == Visibility.FOLLOWERS:
            flash("Пост доступен только для подписчиков автора.", "warning")
        elif post.visibility == Visibility.REQUEST:
            flash("Пост скрыт. Вы можете отправить запрос на доступ.", "warning")
        else:
            flash("Нет доступа к посту.", "danger")
        return redirect(url_for("index"))
    return render_template("post.html", post=post)


@app.route("/post/<int:post_id>/edit", methods=["GET","POST"])
@login_required
def edit_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author.id != current_user.id:
        abort(403)
    if request.method == "POST":
        post.title = request.form.get("title","").strip()
        post.body = request.form.get("body","").strip()
        tags_raw = request.form.get("tags","")
        post.visibility = Visibility(request.form.get("visibility","public"))
        post.tags = parse_tags(tags_raw)
        db.session.commit()
        flash("Пост обновлён.", "success")
        return redirect(url_for("post_detail", post_id=post.id))
    tags_str = ", ".join([t.name for t in post.tags])
    return render_template("edit_post.html", post=post, tags_str=tags_str)


@app.route("/post/<int:post_id>/delete", methods=["POST"])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author.id != current_user.id:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash("Пост удалён.", "info")
    return redirect(url_for("profile", username=current_user.username))


@app.route("/post/<int:post_id>/comment", methods=["POST"])
@login_required
def add_comment(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        abort(403)
    body = request.form.get("body","").strip()
    if not body:
        flash("Комментарий не может быть пустым.", "warning")
        return redirect(url_for("post_detail", post_id=post.id))
    c = Comment(post=post, author=current_user, body=body)
    db.session.add(c)
    db.session.commit()
    return redirect(url_for("post_detail", post_id=post.id))


@app.route("/request_access/<int:post_id>", methods=["POST"])
@login_required
def request_access(post_id):
    post = Post.query.get_or_404(post_id)
    if post.visibility != Visibility.REQUEST:
        flash("Для этого поста запрос не требуется.", "info")
        return redirect(url_for("post_detail", post_id=post.id))
    if post.author.id == current_user.id:
        flash("Вы автор поста.", "info")
        return redirect(url_for("post_detail", post_id=post.id))
    existing = AccessRequest.query.filter_by(post_id=post.id, requester_id=current_user.id).first()
    if existing:
        flash("Запрос уже отправлен.", "info")
    else:
        ar = AccessRequest(post=post, requester=current_user, status="pending")
        db.session.add(ar)
        db.session.commit()
        flash("Запрос отправлен автору.", "success")
    return redirect(url_for("post_detail", post_id=post.id))


@app.route("/requests")
@login_required
def my_requests():
    # запросы на мои посты
    pending = AccessRequest.query.join(Post).filter(Post.user_id==current_user.id, AccessRequest.status=="pending").order_by(AccessRequest.created_at.desc()).all()
    return render_template("access_requests.html", requests=pending)


@app.route("/approve_request/<int:req_id>", methods=["POST"])
@login_required
def approve_request(req_id):
    ar = AccessRequest.query.get_or_404(req_id)
    if ar.post.author.id != current_user.id:
        abort(403)
    ar.status = "approved"
    db.session.commit()
    flash("Доступ предоставлен.", "success")
    return redirect(url_for("my_requests"))


@app.route("/deny_request/<int:req_id>", methods=["POST"])
@login_required
def deny_request(req_id):
    ar = AccessRequest.query.get_or_404(req_id)
    if ar.post.author.id != current_user.id:
        abort(403)
    ar.status = "denied"
    db.session.commit()
    flash("Запрос отклонён.", "info")
    return redirect(url_for("my_requests"))


# CLI command to init DB
@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("Database initialized")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
