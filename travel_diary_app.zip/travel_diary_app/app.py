from datetime import datetime, date
import os, secrets
from flask import Flask, render_template, request, redirect, url_for, flash, abort, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"


# --- Models ---

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    trips = db.relationship("Trip", backref="author", lazy="dynamic")

    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)


class Trip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    start_date = db.Column(db.Date, nullable=True)
    end_date = db.Column(db.Date, nullable=True)
    country = db.Column(db.String(100), default="")
    city = db.Column(db.String(100), default="")
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    cost_total = db.Column(db.Float, nullable=True)
    heritage_sites = db.Column(db.Text, default="")      # перечисление через запятую
    places_to_visit = db.Column(db.Text, default="")     # перечисление через запятую
    rating_comfort = db.Column(db.Integer, default=0)    # 0..5
    rating_safety = db.Column(db.Integer, default=0)     # 0..5
    rating_crowd = db.Column(db.Integer, default=0)      # 0..5
    rating_greenery = db.Column(db.Integer, default=0)   # 0..5
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    images = db.relationship("TripImage", backref="trip", cascade="all, delete-orphan", lazy="dynamic")


class TripImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey("trip.id"), nullable=False)
    path = db.Column(db.String(300), nullable=False)  # относительный путь в static/uploads
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id): return User.query.get(int(user_id))


# --- Helpers ---

def allowed_file(fname: str):
    if "." not in fname: return False
    ext = fname.rsplit(".",1)[1].lower()
    return ext in app.config["ALLOWED_EXTENSIONS"]


def save_images(files):
    saved = []
    upload_dir = app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_dir, exist_ok=True)
    for f in files:
        if not f or f.filename == "":
            continue
        if allowed_file(f.filename):
            base = secure_filename(f.filename)
            uniq = secrets.token_hex(8)
            name, ext = os.path.splitext(base)
            fname = f"{name}-{uniq}{ext}"
            f.save(os.path.join(upload_dir, fname))
            saved.append(os.path.join(upload_dir, fname))
    return saved


def star_row(val: int):
    val = int(val or 0)
    return "★"*val + "☆"*(5-val)


# --- Public pages ---

@app.route("/")
def index():
    trips = Trip.query.order_by(Trip.created_at.desc()).limit(24).all()
    return render_template("index.html", trips=trips)


@app.route("/explore")
def explore():
    q = Trip.query
    # фильтры
    country = request.args.get("country","").strip()
    city = request.args.get("city","").strip()
    user = request.args.get("user","").strip().lower()

    if country:
        q = q.filter(Trip.country.ilike(f"%{country}%"))
    if city:
        q = q.filter(Trip.city.ilike(f"%{city}%"))
    if user:
        q = q.join(User).filter(User.username.ilike(f"%{user}%"))

    sort = request.args.get("sort","new")
    if sort == "cost":
        q = q.order_by(Trip.cost_total.asc().nullsLast())
    elif sort == "alpha":
        q = q.order_by(Trip.title.asc())
    else:
        q = q.order_by(Trip.created_at.desc())

    trips = q.limit(100).all()
    return render_template("explore.html", trips=trips, country=country, city=city, user=user, sort=sort)


@app.route("/trip/<int:trip_id>")
def trip_detail(trip_id):
    t = Trip.query.get_or_404(trip_id)
    return render_template("trip_detail.html", t=t, star_row=star_row)


# --- Auth ---

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not username or not email or not password:
            flash("Заполните все поля.", "danger"); return redirect(url_for("register"))
        if User.query.filter((User.username==username)|(User.email==email)).first():
            flash("Пользователь с таким именем или email уже существует.", "danger"); return redirect(url_for("register"))
        u = User(username=username, email=email); u.set_password(password)
        db.session.add(u); db.session.commit()
        flash("Регистрация успешна. Войдите.", "success"); return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip().lower()
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user); flash("Добро пожаловать!", "success")
            return redirect(url_for("index"))
        flash("Неверные логин/пароль.", "danger")
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user(); flash("Вы вышли.", "info")
    return redirect(url_for("index"))


# --- User: create & manage trips ---

@app.route("/my/trips")
@login_required
def my_trips():
    trips = current_user.trips.order_by(Trip.created_at.desc()).all()
    return render_template("my_trips.html", trips=trips)


@app.route("/trip/new", methods=["GET","POST"])
@login_required
def new_trip():
    if request.method == "POST":
        title = request.form.get("title","").strip()
        desc = request.form.get("description","").strip()
        start_date = request.form.get("start_date")
        end_date = request.form.get("end_date")
        country = request.form.get("country","").strip()
        city = request.form.get("city","").strip()
        latitude = request.form.get("latitude"); longitude = request.form.get("longitude")
        cost_total = request.form.get("cost_total")
        heritage = request.form.get("heritage_sites","").strip()
        places = request.form.get("places_to_visit","").strip()
        rating_comfort = int(request.form.get("rating_comfort","0") or 0)
        rating_safety = int(request.form.get("rating_safety","0") or 0)
        rating_crowd = int(request.form.get("rating_crowd","0") or 0)
        rating_greenery = int(request.form.get("rating_greenery","0") or 0)

        if not title or not desc:
            flash("Заголовок и описание обязательны.", "danger")
            return redirect(url_for("new_trip"))

        t = Trip(
            author=current_user,
            title=title, description=desc,
            start_date=datetime.strptime(start_date, "%Y-%m-%d").date() if start_date else None,
            end_date=datetime.strptime(end_date, "%Y-%m-%d").date() if end_date else None,
            country=country, city=city,
            latitude=float(latitude) if latitude else None,
            longitude=float(longitude) if longitude else None,
            cost_total=float(cost_total) if cost_total else None,
            heritage_sites=heritage, places_to_visit=places,
            rating_comfort=rating_comfort,
            rating_safety=rating_safety,
            rating_crowd=rating_crowd,
            rating_greenery=rating_greenery
        )
        db.session.add(t); db.session.commit()

        imgs = request.files.getlist("images")
        for path in save_images(imgs):
            db.session.add(TripImage(trip=t, path=path))
        db.session.commit()

        flash("Путешествие добавлено.", "success")
        return redirect(url_for("trip_detail", trip_id=t.id))

    return render_template("new_trip.html")


@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("База данных инициализирована.")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
